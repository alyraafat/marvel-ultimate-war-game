Kepler 296 this is an experimental massive grotesque. Supports extended Latin and Cyrillic.

purchase
behance.net/Pj154
pj154f@gmail.com
Igor Kosinsky

By downloading, using, saving or installing the fonts, the user agrees to the following conditions:
- This font is the original copyright product and intellectual property of Igor Kosinsky.
- You can use fonts for free for personal and non-commercial purposes.
- To use fonts for commercial purposes or for purposes seeking to profit, you must purchase licenses.
- Convert the font file to other font formats is possible only with the prior consent of Igor Kosinsky.
- Modifying and making any changes to the font file is prohibited.
- Igor Kosinsky is not responsible for any damage resulting from the use of fonts.